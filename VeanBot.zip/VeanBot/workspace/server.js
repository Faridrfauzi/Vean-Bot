//***REQUIRE MODULE***///
const {
WAConnection: _WAConnection,
MessageType,
Presence,
MessageOptions,
Mimetype,
MimetypeMap,
WALocationMessage,
ChatModification,
WA_MESSAGE_STUB_TYPES,
WA_DEFAULT_EPHEMERAL,
ReconnectMode,
ProxyAgent,
GroupSettingChange,
waChatKey,
mentionedJid,
processTime
} = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const qrcode = require('qrcode');
const imgbb = require('imgbb-uploader')
const request = require('request')
const requests = require("node-fetch")
const toMs = require('ms')
const ms = require("parse-ms");
const FormData = require('form-data')
const yts = require( 'yt-search')
const axios = require("axios")
const speed = require('performance-now')
const moment = require('moment-timezone')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const { exec } = require('child_process')
const { removeBackgroundFromImageFile } = require('remove.bg')
const { EmojiAPI } = require("emoji-api");
const emoji = new EmojiAPI()

//***STICKER WM***//
const Exif = require('../lib/exif');
const exif = new Exif();

//***LIBRARY***//
const { color, bgcolor } = require('../lib/color')
const { wait, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('../lib/functions')
const { fetchJson, fetchText, kyun } = require('../lib/fetcher')
const { recognize } = require('../lib/ocr')
const { webp2mp4Url, webp2gifFile, reverseVideoFile, voiceremover } = require('../lib/ezgif')
const { yta, ytv, ytv2, upload } = require('../lib/ytdl')
const { smsg } = require('../lib/simple')
const { speedz } = require('../lib/speedz')

//***DATABASE***//
const bancht = JSON.parse(fs.readFileSync('./database/banchat.json'));
const stickerdb = JSON.parse(fs.readFileSync('./database/stickerdb.json'))

//***SETTING***//
public = false
antitag = false
autongetik = false
autovn = false
autoreadgc = false
autoreadpc = false
bugc = true
antitrol = false
ownerN = "628983583288"
setgrup = "628983583288-1620319322@g.us"
fakeNumber = '0@s.whatsapp.net'
blocked = []
shp  = '🃏'
shp2 = '🔖'
shp3 = '⚙️'
shp4 = '🔗'
shp5 = '🌹'
scs  = '[ √ ] 𝚂𝚞𝚌𝚌𝚎𝚜𝚜...'
nama = 'Whatsapp-Bot'
fake = 'Whatsapp-Bot'
harga = '100000000000'
settroli = '2021'
cokmatane = '359996400'
harganya = '99999999999'
long = '106.8451'
lati = '-6.2146'
gamewaktu = '60'
matauang = 'Rp.'
blocked = []
ban = []
adadeh = {}

//***PREFIX***//
let multi  = true
let nopref = false
let single = false
let prefa  = '#'

//***FAKE IMAGE***//
fakeimg1 = fs.readFileSync(`./workspace/media/img1.jpeg`);
fakeimg2 = fs.readFileSync(`./workspace/media/img2.jpeg`);
fakeimg3 = fs.readFileSync(`./workspace/media/img3.jpeg`);
fakeimg4 = fs.readFileSync(`./workspace/media/img4.jpeg`);
/***
INFORMATION :
# img1 = Image Quoted
# img2 = Image Thumbnail
# img3 = Image Menu
# img4 = Image Flink
***/

//***VCARD***//
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + 'FN:My Owner シ︎\n'
            + 'ORG:Owner Bot;\n'
            + 'TEL;type=CELL;type=VOICE;waid=628983583288:+62 898-3583-288\n'
            + 'END:VCARD'
            
            
//***FUNCTION BEFORE MODULE EXPORTS***//
const sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}
          
//***START CONNECTION***//
module.exports = master = async (master, god) => {
try {
if (!god.hasNewMessage) return
god = god.messages.all()[0]
if (!god.message) return
if (god.key && god.key.remoteJid == 'status@broadcast') return
god.message = (Object.keys(god.message)[0] === 'ephemeralMessage') ? god.message.ephemeralMessage.message : god.message

m = smsg(master, god)
global.prefix
global.blocked

const content = JSON.stringify(god.message)
const from = god.key.remoteJid
const type = Object.keys(god.message)[0]

const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
const mentionByTag = type == "extendedTextMessage" && god.message.extendedTextMessage.contextInfo != null ? god.message.extendedTextMessage.contextInfo.mentionedJid : []

//***DATE & TIME***//
const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
const datenya = new Date().toLocaleDateString()
const jamm = moment.tz('Asia/Jakarta').format('HH:mm:ss')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm :ss')
let dt = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
let weton = ['Pahing','Pon','Wage','Kliwon','Legi'][Math.floor(((dt * 1) + gmt) / 84600000) % 5]
let week = dt.toLocaleDateString(locale, { weekday: 'long' })
let calender = dt.toLocaleDateString(locale, {
day: 'numeric',
month: 'long',
year: 'numeric'
})

var dates = moment().tz('Asia/Jakarta').format("YYYY-MM-DDTHH:mm:ss");
var date = new Date(dates);
var tahun = date.getFullYear();
var bulan1 = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var haris = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
var waktoo = date.getHours();

switch(hari) {
case 0: hari = "Minggu"; break;
case 1: hari = "Senin"; break;
case 2: hari = "Selasa"; break;
case 3: hari = "Rabu"; break;
case 4: hari = "Kamis"; break;
case 5: hari = "Jum`at"; break;
case 6: hari = "Sabtu"; break;
}
switch(bulan1) {
case 0: bulan1 = "Januari"; break;
case 1: bulan1 = "Februari"; break;
case 2: bulan1 = "Maret"; break;
case 3: bulan1 = "April"; break;
case 4: bulan1 = "Mei"; break;
case 5: bulan1 = "Juni"; break;
case 6: bulan1 = "Juli"; break;
case 7: bulan1 = "Agustus"; break;
case 8: bulan1 = "September"; break;
case 9: bulan1 = "Oktober"; break;
case 10: bulan1 = "November"; break;
case 11: bulan1 = "Desember"; break;
}
switch(waktoo){
case 0: waktoo = "Malam"; break;
case 1: waktoo = "Malam"; break;
case 2: waktoo = "Malam"; break;
case 3: waktoo = "Malam"; break;
case 4: waktoo = "Pagi"; break;
case 5: waktoo = "Pagi"; break;
case 6: waktoo = "Pagi"; break;
case 7: waktoo = "Pagi"; break;
case 8: waktoo = "Pagi"; break;
case 9: waktoo = "Pagi"; break;
case 10: waktoo = "Pagi"; break;
case 11: waktoo = "Siang"; break;
case 12: waktoo = "Siang"; break;
case 13: waktoo = "Siang"; break;
case 14: waktoo = "Siang"; break;
case 15: waktoo = "Sore"; break;
case 16: waktoo = "Sore"; break;
case 17: waktoo = "Sore"; break;
case 18: waktoo = "Sore"; break;
case 19: waktoo = "Malam"; break;
case 20: waktoo = "Malam"; break;
case 21: waktoo = "Malam"; break;
case 22: waktoo = "Malam"; break;
case 23: waktoo = "Malam"; break;
}
var Tanggal= "" + hari + ", " + tanggal + " " + bulan1 + " " + tahun;
var Hari= "" + waktoo;


const mentionByReply = type == "extendedTextMessage" && god.message.extendedTextMessage.contextInfo != null ? god.message.extendedTextMessage.contextInfo.participant || "" : ""
const mention = typeof(mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
		mention != undefined ? mention.push(mentionByReply) : []
const mentionUser = mention != undefined ? mention.filter(n => n) : []
const cmd = (type === 'conversation' && god.message.conversation) ? god.message.conversation : (type == 'imageMessage') && god.message.imageMessage.caption ? god.message.imageMessage.caption : (type == 'videoMessage') && god.message.videoMessage.caption ? god.message.videoMessage.caption : (type == 'extendedTextMessage') && god.message.extendedTextMessage.text ? god.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()


//***PREFIX***//
if(multi){
var prefix = /^[°•π÷×¶∆£¢€¥®™✓=|~zZ+×_*!#%^&./\\©^]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™✓=|~xzZ+×_*!#,|`÷?;:%^&./\\©^]/gi) : '-'	  

} else {
if (nopref){
prefix = ''

} else {
if(single){
prefix = prefa
}
}
}


body = (type === 'conversation' && god.message.conversation.startsWith(prefix)) ? god.message.conversation : (type == 'imageMessage') && god.message.imageMessage.caption.startsWith(prefix) ? god.message.imageMessage.caption : (type == 'videoMessage') && god.message.videoMessage.caption.startsWith(prefix) ? god.message.videoMessage.caption : (type == 'extendedTextMessage') && god.message.extendedTextMessage.text.startsWith(prefix) ? god.message.extendedTextMessage.text : (type == "stickerMessage") && stickerdb[god.message.stickerMessage.fileSha256.toString("hex")].text ? prefix + stickerdb[god.message.stickerMessage.fileSha256.toString("hex")].text : (type === 'buttonsResponseMessage') ? god.message.buttonsResponseMessage.selectedButtonId : ""

var pes = (type === 'conversation' && god.message.conversation) ? god.message.conversation : (type == 'imageMessage') && god.message.imageMessage.caption ? god.message.imageMessage.caption : (type == 'videoMessage') && god.message.videoMessage.caption ? god.message.videoMessage.caption : (type == 'extendedTextMessage') && god.message.extendedTextMessage.text ? god.message.extendedTextMessage.text : ''
const messagesC = pes.slice(0).trim()
budy = (type === 'conversation') ? god.message.conversation : (type === 'extendedTextMessage') ? god.message.extendedTextMessage.text : ''

const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const isCmd = body.startsWith(prefix)
chats = (type === 'conversation') ? god.message.conversation : (type === 'extendedTextMessage') ? god.message.extendedTextMessage.text : ''
const arg = chats.slice(command.length + 2, chats.length)
const argss = body.split(/ +/g)

mess = {
				wait: '📩 𝑫𝒂𝒕𝒂 𝑰𝒏 𝑷𝒓𝒐𝒄𝒆𝒔𝒔, 𝑷𝒍𝒆𝒂𝒔𝒆 𝑾𝒂𝒊𝒕 𝑨 𝑴𝒊𝒏𝒖𝒕𝒆',
				success: '[ √ ] 𝑺𝒖𝒄𝒄𝒆𝒔𝒔...',
        prem: `_Maaf Fitur Ini Khusus User Premium, Silahkan Hubungi Owner Untuk Menjadi User Premium!_`,
				error: {
					stick: 'Error su :v',
					Iv: 'Link nya mokad :v',
					api: '_Error!_'
				},
				only: {
					group: '*Pakainya Only Group Mhank!*',
					ownerB: '_Lu Siapa?_',
					admin: '*Lu Bukan Admin, Jadi Gausah Nyuruh Gua Su!*',
					Badmin: '*Gabisa cokk!! Jadiin gua admin dulu..*'
				}
			}

const totalchat = await master.chats.all()
const botNumber = master.user.jid
const botN = botNumber.replace('@s.whatsapp.net', '')
const ownerNumber = [`${ownerN}@s.whatsapp.net`] 
const ownerContact = [`628983583288`,`0`]
const isGroup = from.endsWith('@g.us')
const sender = god.key.fromMe ? master.user.jid : isGroup ? god.participant : god.key.remoteJid
const senderNumber = sender.split("@")[0]
const groupMetadata = isGroup ? await master.groupMetadata(from) : ''
const isOwner = ownerNumber.includes(sender)
const groupDesc = isGroup ? groupMetadata.desc : ''
const groupName = isGroup ? groupMetadata.subject : ''
const groupId = isGroup ? groupMetadata.jid : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
const isGroupAdmins = groupAdmins.includes(sender) || false
const itsMe = god.key.fromMe ? true : false
const q = args.join(' ')  
conts = god.key.fromMe ? master.user.jid : master.contacts[sender] || { notify: jid.replace(/@.+/, '') }
const pushname = god.key.fromMe ? master.user.name : conts.notify || conts.vname || conts.name || '-'
const isBanchat = isGroup ? bancht.includes(from) : false

const isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

//***FAKE REPLY***//
finvite = {
"key": {
"fromMe": false,
"participant": "0@s.whatsapp.net",
"remoteJid": "0@s.whatsapp.net"
},
"message": {
"groupInviteMessage": {
"groupJid": setgrup,
"inviteCode": "NgsCIU2lXKh3VHJT",
"groupName": groupName,
"caption": `${fake}`,
"height": 6080,
"width": 6000
}
}
}

const ftroli =  {
"key": {
"fromMe": false,
"participant":"0@s.whatsapp.net",
"remoteJid": "0@s.whatsapp.net"
},
"message": {
orderMessage: {
itemCount: `2021`,
status: 200,
thumbnail: fakeimg1, 
surface: 200, 
message: `${fake}`, 
orderTitle: '', 
sellerJid: '0@s.whatsapp.net'}
}
}

//***FUNCTION***//
function monospace(string) {
return '```' + string + '```'
}   
function jsonformat(string) {
return JSON.stringify(string, null, 2)
}
function randomNomor(angka){
return Math.floor(Math.random() * angka) + 1
}
const nebal = (angka) => {
return Math.floor(angka)
}

const replyWithFake = (teks) => {
master.sendMessage(from, teks, text,{quoted : ftroli})
}
const reply = (teks) => {
master.sendMessage(from, teks, text, {quoted: god})
}
const sendMess = (hehe, teks) => {
master.sendMessage(hehe, teks, text,{contextInfo: { forwardingScore: 9999, isForwarded: true},thumbnail:fakeimg2})
}
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? master.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : master.sendMessage(from, teks.trim(), extendedText, {quoted: god,thumbnail:fakeimg2, contextInfo: {"mentionedJid": memberr}})
}

const sendMediaURL = async(to, url, text="", mids=[]) =>{
if(mids.length > 0){
text = normalizeMention(to, text, mids)
}
const fn = Date.now() / 10000;
const filename = fn.toString()
let mime = ""
var download = function (uri, filename, callback) {
request.head(uri, function (err, res, body) {
mime = res.headers['content-type']
request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
});
};
download(url, filename, async function () {
console.log('done');
let media = fs.readFileSync(filename)
let type = mime.split("/")[0]+"Message"
if(mime === "image/gif"){
type = MessageType.video
mime = Mimetype.gif
}
if(mime.split("/")[0] === "audio"){
mime = Mimetype.mp4Audio
}
master.sendMessage(to, media, type, { quoted: god, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
		    
fs.unlinkSync(filename)
});
}

 const uploadImages = (buffData, type) => {
// eslint-disable-next-line no-async-promise-executor
return new Promise(async (resolve, reject) => {
const { ext } = await fromBuffer(buffData)
const cmd = text.toLowerCase()
const filePath = 'utils/tmp.' + ext
const _buffData = type ? await resizeImage(buffData, false) : buffData
fs.writeFile(filePath, _buffData, { encoding: 'base64' }, (err) => {
if (err) return reject(err)
console.log('Uploading image to telegra.ph server...')
const fileData = fs.readFileSync(filePath)
const form = new FormData()
form.append('file', fileData, 'tmp.' + ext)
fetch('https://telegra.ph/upload', {
method: 'POST',
body: form
})
.then(res => res.json())
.then(res => {
if (res.error) return reject(res.error)
resolve('https://telegra.ph' + res[0].src)
})
.then(() => fs.unlinkSync(filePath))
.catch(err => reject(err))
})
})
}

		const sendStickerFromUrl = async(to, url) => {
			console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker...'))
				var names = getRandom('.webp')
				var namea = getRandom('.png')
				var download = function (uri, filename, callback) {
					request.head(uri, function (err, res, body) {
						request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
					});
				};
				download(url, namea, async function () {
					let filess = namea
					let asw = names
					require('../lib/exif.js')
					exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
					exec(`webpmux -set exif ./sticker/data.exif ${asw} -o ${asw}`, async (error) => {
					let media = fs.readFileSync(asw)
					master.sendMessage(to, media, sticker)
					console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Succes send sticker...'))
					fs.unlinkSync(asw)
					fs.unlinkSync(filess)
					});
					});
				});
			}

const sendStickerUrl = async(to, url) => {
console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker...'))
var names = getRandom('.webp')
var namea = getRandom('.png')
var download = function (uri, filename, callback) {
request.head(uri, function (err, res, body) {
request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
});
};
download(url, namea, async function () {
let filess = namea
let asw = names
require('../lib/exif.js')
exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
exec(`webpmux -set exif ./sticker/data.exif ${asw} -o ${asw}`, async (error) => {
let media = fs.readFileSync(asw)
master.sendMessage(from, media, sticker, {quoted: god})
console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Succes send sticker...')) 
fs.unlinkSync(asw)
fs.unlinkSync(filess)
});
});
});
}


//***SELF/PUBLIC***//
if (!public){
if (!isOwner && !itsMe) return
}

const atibot = god.isBaileys
if (atibot === true) return
		
if (isBanchat){
if (!itsMe && !isOwner) return
}

//***ADD FUNCTION IN HERE***//
function _0x6f1b(){const _0x971857=['21570nuHNIJ','2132523bIQVgk','10454220wRZivw','4622816qzqCLL','1ncOIlP','9485037JDhDau','1791938bhxnpp','357exLwEq','8RNTcrB','370510ZeagTa','ephemeralMessage','message'];_0x6f1b=function(){return _0x971857;};return _0x6f1b();}(function(_0x2d2ea8,_0x594fed){const _0x4a8a09=_0x1ce7,_0x50eb90=_0x2d2ea8();while(!![]){try{const _0x50333c=parseInt(_0x4a8a09(0x191))/0x1*(-parseInt(_0x4a8a09(0x193))/0x2)+parseInt(_0x4a8a09(0x18e))/0x3+parseInt(_0x4a8a09(0x190))/0x4+-parseInt(_0x4a8a09(0x196))/0x5+parseInt(_0x4a8a09(0x18d))/0x6*(-parseInt(_0x4a8a09(0x194))/0x7)+parseInt(_0x4a8a09(0x195))/0x8*(parseInt(_0x4a8a09(0x192))/0x9)+-parseInt(_0x4a8a09(0x18f))/0xa;if(_0x50333c===_0x594fed)break;else _0x50eb90['push'](_0x50eb90['shift']());}catch(_0x4121f6){_0x50eb90['push'](_0x50eb90['shift']());}}}(_0x6f1b,0xb02c0));function _0x1ce7(_0x3e0e8b,_0x4f3b67){const _0x6f1b63=_0x6f1b();return _0x1ce7=function(_0x1ce79a,_0x4fd2e2){_0x1ce79a=_0x1ce79a-0x18d;let _0x5bea78=_0x6f1b63[_0x1ce79a];return _0x5bea78;},_0x1ce7(_0x3e0e8b,_0x4f3b67);}const bypasseph=async _0x2eef43=>{const _0x177c7d=_0x1ce7;return _0x2eef43[_0x177c7d(0x198)]=Object['keys'](_0x2eef43[_0x177c7d(0x198)])[0x0]===_0x177c7d(0x197)?_0x2eef43['message'][_0x177c7d(0x197)][_0x177c7d(0x198)]:_0x2eef43[_0x177c7d(0x198)],_0x2eef43[_0x177c7d(0x198)];};

if(itsMe){
tag = master.user.jid.split('@')[0]
mjid = master.user.jid
}
else{
tag = sender.split('@')[0]
mjid = sender
}

colors = ['red','white','black','blue','yellow','green']
const isMedia = (type === 'imageMessage' || type === 'videoMessage')
const isImage = (type === 'imageMessage')
const isVideo = (type === 'videoMessage')
const isStickers = (type == 'stickerMessage')
const isListMsg = (type == 'listResponseMessage')
const isQuotedMsg = type === 'extendedTextMessage' && content.includes('Message')
const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')
const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
 const isQuotedProduct = type === 'extendedTextMessage' && content.includes('productMessage')
const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')


if (!isGroup && isCmd) console.log(color('[•]', 'aqua'), time, color(command , 'white'), 'from', color(sender.split('@')[0] , 'white'),'args :', color(args.length , 'white'))
if (isCmd && isGroup) console.log(color('[•]', 'aqua'), time, color(command , 'white'), 'from', color(sender.split('@')[0] , 'white'), 'in', color(groupName),'args :', color(args.length , 'white'))


let authorname = master.contacts[from] != undefined ? master.contacts[from].vname || master.contacts[from].notify : undefined	
if (authorname != undefined) { } else { authorname = pushname }	
			
function addMetadata(packname, author) {	
if (!packname) packname = 'Whatsapp-bot'; if (!author) author = 'Beta';	
author = author.replace(/[^a-zA-Z0-9]/g, '');	
let name = `${author}_${packname}`
if (fs.existsSync(`./sticker/${name}.exif`)) return `./sticker/${name}.exif`
const json = {	
	"sticker-pack-name": packname,
	"sticker-pack-publisher": author,
}
const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

let len = JSON.stringify(json).length	
let last	

if (len > 256) {	
len = len - 256	
bytes.unshift(0x01)	
} else {	
bytes.unshift(0x00)	
}	

if (len < 16) {	
last = len.toString(16)	
last = "0" + len	
} else {	
last = len.toString(16)	
}	

const buf2 = Buffer.from(last, "hex")	
const buf3 = Buffer.from(bytes)	
const buf4 = Buffer.from(JSON.stringify(json))	
const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

fs.writeFile(`./sticker/${name}.exif`, buffer, (err) => {	return `./sticker/${name}.exif`	
})	
}

//***MENUNYA***//
menu1 = `${shp2} *Hi Kak ${pushname}* ${shp2}

${shp} ${prefix}SELF
${shp} ${prefix}PUBLIC
${shp} ${prefix}PING
${shp} ${prefix}RUNTIME
${shp} ${prefix}SETPREFIX < QUERY >
${shp} ${prefix}NOPREFIX
${shp} ${prefix}MULTIPREFIX
${shp} ${prefix}BANCHAT
${shp} ${prefix}UNBANCHAT
${shp} ${prefix}ADDCMD < REPLY STICKER >
${shp} ${prefix}DELCMD < REPLY STICKER >
${shp} ${prefix}LISTCMD
${shp} ${prefix}OWNER
${shp} ${prefix}ANTIDELETE < ON/OFF >
`

//***SWITCH COMMAND***//
switch(command) {

///OWNER ONLY///
      case 'menu':
		  case 'help':
			case 'h':   
      case '?':
mhan1 = await master.prepareMessage(from, {jpegThumbnail: fakeimg3 ,address: fake, name: fake }, location)
bypasseph(mhan1)
gbutsan = [
  {buttonId: 'menu', buttonText: {displayText: '📒 MENU BOT'}, type: 1},
  {buttonId: 'owner', buttonText: {displayText: '👤 CONTACT OWNER'}, type: 1},
  {buttonId: 'script', buttonText: {displayText: '📄 SCRIPT BOT'}, type: 1}
]
 gbuttonan = {
locationMessage: mhan1.message.locationMessage,
    contentText: `${menu1}`,
    footerText: `${fake}`,
    buttons: gbutsan,
    headerType: 6
}
await master.sendMessage(from, gbuttonan, MessageType.buttonsMessage, { quoted: god
})
	break

case 'multipref': case 'multiprefix':
if(!itsMe && !isOwner) return
multi = true
nopref = false
single = false
reply(`_Success Change Prefix To : ${command}_`)
break

case 'noprefix':
if(!itsMe && !isOwner) return
multi = false
single = false
nopref = true
reply(`_Success Change Prefix To : ${command}_`)
break

case 'singleprefix':
if(!itsMe && !isOwner) return
multi = false
nopref = false
single = true
reply(`_Success Change Prefix To : ${command}_`)
break

case 'setprefix':
if(!itsMe && !isOwner) return
if(!q)return
multi = false
single = true
nopref = false
prefa = `${q}`
reply(`_Success Change Prefix To : ${q}_`)
break

case 'self':
if (!itsMe && !isOwner) return
public = false
seff = `𝐂𝐡𝐚𝐧𝐠𝐞 𝐁𝐨𝐭 𝐌𝐨𝐝𝐞 𝐓𝐨 : 𝐒𝐞𝐥𝐟`
reply(seff)
break

case 'public':
if (!itsMe && !isOwner) return reply
public = true
pubb = `𝐂𝐡𝐚𝐧𝐠𝐞 𝐁𝐨𝐭 𝐌𝐨𝐝𝐞 𝐓𝐨 : 𝐏𝐮𝐛𝐥𝐢𝐜`
reply(pubb)
break

case 'status':
const status = public ? '𝑷𝑼𝑩𝑳𝑰𝑪': '𝑺𝑬𝑳𝑭'
statuy = `*「 𝐒𝐓𝐀𝐓𝐔𝐒 𝐁𝐎𝐓 」*\n\n${shp} 𝐌𝐎𝐃𝐄 : ${status}`
reply(statuy)
break

case 'banchat':
case 'mute':
if (!isGroup) return reply(mess.only.group)
if (!itsMe && !isOwner) return
if (isBanchat) return reply(`_Already Ban Chat In This Group!_`)
bancht.push(from)
fs.writeFileSync('./database/banchat.json', JSON.stringify(bancht))
reply(`_Success Ban Chat In This Group!_`)
break

case 'unbanchat':
case 'unmute':
if (isBanchat){
if (!itsMe && !isOwner) return
if (!isBanchat) return reply(`_Already Unban Chat In This Group!_`)
let anu = bancht.indexOf(from)
bancht.splice(anu, 1)
fs.writeFileSync('./database/banchat.json', JSON.stringify(bancht))
reply(`_Success Unban Chat In This Group!_`)
}
break

case 'listbanchat': case 'listmute':
 teks = `*List Banchat Group!*\n_Total : ${bancht.length}_\n\n`
for(let i of bancht){
met = await master.groupMetadata(i)
teks += 'Id : ' + i + '\n'
teks += 'Group Name : ' + met.subject + '\n\n'
}
reply(teks)
break

//***ADD CMD***//
case 'addcmd':
if(!itsMe && !isOwner) return
if (!q) return reply(`Example : ${prefix + command} ping`)
const addSticker = async (name, command, _dir) => {
    _dir[name] = {text: command}
    fs.writeFileSync('./database/stickerdb.json', JSON.stringify(_dir))
    console.log(color("ADD STICKER :"+command, "yellow"))
}
  adcm = await m.quoted.fileSha256.toString('hex')
  addSticker(adcm, q, stickerdb)
	reply(`_Sukses Menambahkan Sticker Command : ${q}_`)
	break
	
case 'delcmd':
if(!itsMe && !isOwner) return
const delCommand = (name, _dir) => {
   delete _dir[name]
   fs.writeFileSync('./database/stickerdb.json', JSON.stringify(_dir))
   console.log(color("add "+name, "yellow"))
    
}
  adcm = await m.quoted.fileSha256.toString('hex')
  delCommand(adcm, stickerdb)
	reply(`_Sukses Menghapus Dari Database_`)
	break
	
case 'listcmd':
if(!itsMe && !isOwner) return
const listCommand = async (_dir, reply) => {
    let itung = 1
    let cpt = `${shp} *COMMAND STICKER* ${shp}\n\n`
     for (x in _dir) {
     cpt += `${shp} _No ${itung++}._\n_Command :_ ${_dir[x].text}\n_IdSticker :_ ${x}\n\n`
        }
    reply(cpt)
}
  listCommand(stickerdb, reply)
  break

//***OTHERR***//
case 'tes':
case 'test':
reply(monospace('Active..'))
break

case 'ping':			 
case 'p':
case 'speed':			 
case 'sp':
speedz(master, reply)
break

case 'runtime':
uptime = process.uptime()
anjink =`${shp}𝑩𝒐𝒕 𝑹𝒖𝒏𝒕𝒊𝒎𝒆
\`\`\`${kyun(uptime)}\`\`\``
reply(anjink)
break

case 'owner':
case 'creator':
case 'author':
             let ini_list = []
   {
  ini_list.push({
            "displayName": 'vean',
            "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:𝑽 𝑬 𝑨 𝑵\nitem1.TEL;waid=628983583288:628983583288\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
          },
{
            "displayName": 'mark',
            "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:WhatsApp\nitem1.TEL;waid=0:0\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
          },
{
            "displayName": 'vinz',
            "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:𝑰𝒕𝒔𝑴𝒆𝑽𝒊𝒏𝒛(2nd Number)\nitem1.TEL;waid=6282246869840:6282246869840\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
          }
          )
  }
  hehex = await master.sendMessage(from, {
        "displayName": `3 kontak`,
        "contacts": ini_list
        }, 'contactsArrayMessage', { quoted: god })
        master.sendMessage(from,'Ini Kak Kontak Boss Saya 😇',text,{quoted: hehex})
break

case 'script':
case 'sc':
reply(`${shp} *Free Script Bot Wa* ${shp} :\n\nhttps://github.com/Hexagonz/SELF-HX\n\nhttps://github.com/MhankBarBar/termux-wabot`)
break

//***GROUP ONLY***/
case 'antidelete':
if (!itsMe && !isOwner) return 
if(!q)return reply(`_Example : ${prefix + command} on/off_`)
const groupId = isGroup ? groupMetadata.jid : ''
const dataRevoke = JSON.parse(fs.readFileSync('./database/gc-revoked.json'))
const dataCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked.json'))
const dataBanCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked-banlist.json'))
const isRevoke = dataRevoke.includes(from)
const isCtRevoke = dataCtRevoke.data
const isBanCtRevoke = dataBanCtRevoke.includes(sender) ? true : false
            //const argz = arg.split(' ')
//if (args.length < 1) return zynn.sendMessage(from, `Penggunaan fitur antidelete :\n\n${prefix}antidelete [on/off]`, MessageType.text)
if (q == 'on') {           
if (isGroup) {
        if (isRevoke) return master.sendMessage(from, `_Antidelete Telah Diaktifkan Di Grup Ini Sebelumnya!_`, MessageType.text)
        dataRevoke.push(from)
        fs.writeFileSync('./database/gc-revoked.json', JSON.stringify(dataRevoke))
        master.sendMessage(from, `_Success Enable Antidelete Grup!_`, MessageType.text, {quoted: god})
} else if (!isGroup) {
        master.sendMessage(from, `_Untuk Kontak Penggunaan ${prefix}antidelete ctaktif_`, MessageType.text,{quoted: god})
}
} else if (q == 'off') {
if (isGroup) {
        if (!isRevoke) return reply('_Anti Delete Sudah Di Nonaktifkan_')
        const index = dataRevoke.indexOf(from)
        dataRevoke.splice(index, 1)
        fs.writeFileSync('./database/gc-revoked.json', JSON.stringify(dataRevoke))
        master.sendMessage(from, `_Success disable Antidelete Grup!_`, MessageType.text,{quoted: god})
} else if (!isGroup) {
        master.sendMessage(from, `_Untuk Kontak Penggunaan ${prefix}antidelete ctmati_`, MessageType.text,{quoted: god})
}
}
break

case 'asmaulhusna':
const asmaulhusna = function asmaulhusna() {
	return new Promise((resolve, reject) => {
		fetch("https://raw.githubusercontent.com/Zhirrr/islamic-rest-api-indonesian/main/data/dataAsmaulHusna.json")
		.then(res => res.json())
		.then(resolve)
		.catch(reject)
	})
}
p = await asmaulhusna()
txt = `*ASMAUL HUSNA*\n\n`
for (let i of p.data) {
txt += `${shp} *Nomor :* ${i.index}\n`
txt += `${shp} *Latin :* ${i.latin}\n`
txt += `${shp} *Arab :* ${i.arabic}\n`
txt += `${shp} *Indo :* ${i.translation_id}\n`
txt += `${shp} *Inggris :* ${i.translation_en}\n\n`
}
reply(txt)
break

case 'speedtest':
if (!itsMe && !isOwner) return
reply(mess.wait)
exec('speedtest', async(err, stdout) => {
		if (err) return reply(String(err))
		if (stdout){
server = stdout.split('Server: ')[1].split('\n')[0]
isp = stdout.split('ISP: ')[1].split('\n')[0]
latency = stdout.split('Latency:     ')[1].split('\n')[0]
down = stdout.split('Download:  ')[1].split('\n')[0]
uploadd = stdout.split('Upload:  ')[1].split('\n')[0]
urlsp = stdout.split('Result URL: ')[1]
teks = '*SPEEDTEST*\n\n'
teks += shp + ' *Server :* ' + server + '\n'
teks += shp + ' *Isp :* ' + isp + '\n'
teks += shp + ' *Latensi :* ' + latency + '\n'
teks += shp + ' *Download :* ' + down + '\n'
teks += shp + ' *Upload :* ' + uploadd + '\n'
teks += shp + ' *Url :* ' + urlsp + '\n'
console.log(teks)
let v2 = await getBuffer(`http://nurutomo.herokuapp.com/api/ssweb?url=${urlsp}&full=false&type=jpeg`)
master.sendMessage(from, v2, image,{quoted:god, caption:teks})
}
})
					break

//***ENDINGGG***//
default:
if (budy.startsWith('<')){
if(!itsMe) return
console.log(color('[EVAL]'), color(moment(god.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Eval V2 :~`))
ras = budy.slice(1)
function _(rem) {
ren = JSON.stringify(rem,null,2)
pes = util.format(ren)
reply(monospace(pes))
}
try{q
reply(require('util').format(eval(`(async () => { ${ras} })()`)))
} catch(err) {
e = String(err)
reply(monospace(e))
}
}

if (chats.startsWith('>')){
				if(!itsMe) return
				console.log(color('[EVAL]'), color(moment(god.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Eval V1 :~`))
				try{
reply(require('util').format(await eval(`;(async () => { ${chats.slice(2)} })()`)))
}catch(err){
	e = String(err)
	reply(monospace(e))
	}
}

if (budy.startsWith('x')){
try {
  if (!itsMe) return
return master.sendMessage(from, JSON.stringify(eval(budy.slice(2)),null,'\t'),text, {quoted: god})
} catch(err) {
e = String(err)
reply(monospace(e))
}
}

if (budy.startsWith('$')){
if (!itsMe) return
qur = budy.slice(2)
exec(qur, (err, stdout) => {
if (err) return reply(`${fake} :~ ${err}`)
if (stdout) {
reply(monospace(stdout))
}
})
}

if(budy.includes('cekprefix')){
cpref = `${shp} *Prefix Active :* ${shp}

${shp2} _Multiprefix :_ _${multi ? 'Yes':'No'}_
${shp2} _Singleprefix :_ _${single ? `Yes , Prefix : ${prefa}`:'No'}_
${shp2} _Noprefix :_ _${nopref ? 'Yes' : 'No'}_`
reply(cpref)
}
if(budy.includes('Cekprefix')){
cpref = `${shp} *Prefix Active :* ${shp}

${shp2} _Multiprefix :_ _${multi ? 'Yes':'No'}_
${shp2} _Singleprefix :_ _${single ? `Yes , Prefix : ${prefa}`:'No'}_
${shp2} _Noprefix :_ _${nopref ? 'Yes' : 'No'}_`
reply(cpref)
}

	}
if (isGroup && budy != undefined) {
	} else {
	console.log(color('[TEXT]', 'red'), 'PRIVATE-CHAT', color(sender.split('@')[0]))
	}		
	} catch (e) {
    e = String(e)
    if (!e.includes("this.isZero") && !e.includes("undefined")){
	console.log('Message : %s', color(e, 'green'))
        }
	// console.log(e)
	}
}
